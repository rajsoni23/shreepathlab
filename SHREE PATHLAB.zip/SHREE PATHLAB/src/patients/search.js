function loadPatients(){

let tx=db.transaction(["patients"],"readonly");

let store=tx.objectStore("patients");

let request=store.getAll();

request.onsuccess=function(){

displayPatients(request.result);

};

}

function displayPatients(data){

let tbody=document.getElementById("patientTable");

tbody.innerHTML="";

data.forEach(patient=>{

tbody.innerHTML+=`

<tr>

<td>${patient.labId}</td>

<td>${patient.name}</td>

<td>${patient.age}</td>

<td>${patient.gender}</td>

<td>${patient.mobile}</td>

<td>

<button onclick="deletePatient(${patient.id})">Delete</button>

</td>

</tr>

`;

});

}

function deletePatient(id){

if(confirm("Delete Patient?")){

let tx=db.transaction(["patients"],"readwrite");

let store=tx.objectStore("patients");

store.delete(id);

tx.oncomplete=function(){

loadPatients();

};

}

}

document.getElementById("searchBox").addEventListener("keyup",function(){

let value=this.value.toLowerCase();

let tx=db.transaction(["patients"],"readonly");

let store=tx.objectStore("patients");

let request=store.getAll();

request.onsuccess=function(){

let filtered=request.result.filter(p=>

p.name.toLowerCase().includes(value)||

p.labId.toLowerCase().includes(value)||

(p.mobile||"").includes(value)

);

displayPatients(filtered);

};

});

function onDatabaseReady() {
    loadPatients();
}