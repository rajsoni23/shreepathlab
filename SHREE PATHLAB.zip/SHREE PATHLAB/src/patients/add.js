function generateLabId(){

let number=Date.now();

return "LAB"+number;

}

document.getElementById("labId").value=generateLabId();

document.getElementById("patientForm").addEventListener("submit",function(e){

e.preventDefault();

let tx=db.transaction(["patients"],"readwrite");

let store=tx.objectStore("patients");

store.add({

labId:document.getElementById("labId").value,

name:document.getElementById("name").value,

age:document.getElementById("age").value,

gender:document.getElementById("gender").value,

mobile:document.getElementById("mobile").value,

doctor:document.getElementById("doctor").value,

address:document.getElementById("address").value,

sample:document.getElementById("sample").value,

created:new Date()

});

tx.oncomplete=function(){

alert("Patient Saved Successfully");

location.reload();

};

});