let db;

const request = indexedDB.open("PathoLabDB",1);

request.onupgradeneeded=function(e){

db=e.target.result;

if(!db.objectStoreNames.contains("patients")){

let store=db.createObjectStore("patients",{
keyPath:"id",
autoIncrement:true
});

store.createIndex("labId","labId",{unique:true});
store.createIndex("name","name",{unique:false});
store.createIndex("mobile","mobile",{unique:false});

}

};

request.onsuccess=function(e){

db=e.target.result;

console.log("Database Connected");

};

request.onerror=function(){

console.log("Database Error");

};