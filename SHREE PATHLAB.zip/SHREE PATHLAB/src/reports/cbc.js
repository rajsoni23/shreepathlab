document.getElementById("saveBtn").addEventListener("click",function(){

let report={

patientId:Number(document.getElementById("patientList").value),

hb:document.getElementById("hb").value,

wbc:document.getElementById("wbc").value,

rbc:document.getElementById("rbc").value,

platelets:document.getElementById("platelets").value,

esr:document.getElementById("esr").value,

date:new Date().toLocaleDateString(),

time:new Date().toLocaleTimeString()

};

let tx=db.transaction(["reports"],"readwrite");

let store=tx.objectStore("reports");

store.add(report);

tx.oncomplete=function(){

alert("CBC Report Saved Successfully");

};

});