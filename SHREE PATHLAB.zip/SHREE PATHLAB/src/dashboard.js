document.getElementById("patients").innerHTML = 0;

document.getElementById("reports").innerHTML = 0;